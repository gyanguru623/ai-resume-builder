package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ads.AdManager
import com.example.ai.GeminiAiService
import com.example.data.local.AppDatabase
import com.example.data.repository.ResumeRepository
import com.example.ui.MainViewModel
import com.example.ui.screens.*
import com.example.ui.theme.AIResumeBuilderTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Google AdMob SDK
        AdManager.initialize(applicationContext)

        val database = AppDatabase.getDatabase(applicationContext)
        val repository = ResumeRepository(database.resumeDao(), database.coverLetterDao())
        val aiService = GeminiAiService(applicationContext)
        val viewModel = MainViewModel(application, repository, aiService)

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            AIResumeBuilderTheme(darkTheme = isDarkMode) {
                AppNavigation(viewModel)
            }
        }
    }
}

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "splash",
        modifier = Modifier.fillMaxSize()
    ) {
        composable("splash") {
            SplashScreen(
                onNavigateOnboarding = {
                    navController.navigate("onboarding") {
                        popUpTo("splash") { inclusive = true }
                    }
                },
                onNavigateDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("splash") { inclusive = true }
                    }
                }
            )
        }

        composable("onboarding") {
            OnboardingScreen(
                onFinish = {
                    navController.navigate("dashboard") {
                        popUpTo("onboarding") { inclusive = true }
                    }
                }
            )
        }

        composable("dashboard") {
            MainDashboardScreen(
                viewModel = viewModel,
                onEditResume = { resume ->
                    viewModel.updateActiveResume(resume)
                    navController.navigate("editor")
                },
                onOpenPdfExport = { resume ->
                    viewModel.updateActiveResume(resume)
                    navController.navigate("pdf_export")
                },
                onNavigateToAtsChecker = { navController.navigate("ats_checker") },
                onNavigateToCoverLetter = { navController.navigate("cover_letter") },
                onNavigateToInterview = { navController.navigate("interview") },
                onNavigateToCareerTips = { navController.navigate("career_tips") },
                onNavigateToSettings = { navController.navigate("settings") }
            )
        }

        composable("editor") {
            ResumeEditorScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenExport = { navController.navigate("pdf_export") }
            )
        }

        composable("ats_checker") {
            AtsCheckerScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable("cover_letter") {
            CoverLetterScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable("interview") {
            InterviewQuestionsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable("career_tips") {
            CareerTipsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable("pdf_export") {
            PdfExportScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable("settings") {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
