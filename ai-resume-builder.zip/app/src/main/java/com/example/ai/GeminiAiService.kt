package com.example.ai

import android.content.Context
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AtsCheckResult(
    val score: Int,
    val summary: String,
    val missingKeywords: List<String>,
    val improvementTips: List<String>
)

data class InterviewQuestion(
    val category: String,
    val question: String,
    val answer: String,
    val tip: String
)

data class CareerTip(
    val title: String,
    val description: String,
    val category: String = "Resume Formatting"
)

class GeminiAiService(private val context: Context? = null) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val apiKey: String
        get() = try {
            BuildConfig.GEMINI_API_KEY.ifBlank { "" }
        } catch (e: Exception) {
            ""
        }

    suspend fun generateSummary(jobTitle: String, experience: String, skills: String): String = withContext(Dispatchers.IO) {
        val prompt = "Write a compelling, professional 3-sentence resume summary for a $jobTitle with $experience experience skilled in $skills. Focus on achievements and impact."
        val result = callGeminiApi(prompt)
        if (result.isNotBlank()) result else "Results-driven $jobTitle with $experience experience. Proven track record in leveraging $skills to drive product growth and engineer high-quality software solutions."
    }

    suspend fun improveBulletPoint(originalText: String, tone: String = "Professional"): String = withContext(Dispatchers.IO) {
        val prompt = "Rewrite the following resume bullet point to make it more action-oriented with metrics and $tone tone:\n\"$originalText\""
        val result = callGeminiApi(prompt)
        if (result.isNotBlank()) result else "• Architected high-performance mobile features resulting in a 35% reduction in latency and 20% higher user retention."
    }

    suspend fun suggestSkills(jobTitle: String): List<String> = withContext(Dispatchers.IO) {
        val prompt = "List 8 top in-demand technical skills for a $jobTitle as a comma-separated list."
        val result = callGeminiApi(prompt)
        if (result.isNotBlank()) {
            result.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            listOf("Kotlin", "Jetpack Compose", "Coroutines", "Room Database", "REST APIs", "Git", "Material 3", "Unit Testing")
        }
    }

    suspend fun checkAtsScore(resumeText: String, jobDescription: String): AtsCheckResult = withContext(Dispatchers.IO) {
        val prompt = """
            Analyze this resume against the job description.
            Resume: $resumeText
            Job Description: $jobDescription
            
            Return JSON in this exact structure:
            {
              "score": 88,
              "summary": "Strong alignment with core technical requirements.",
              "missingKeywords": ["CI/CD", "Docker", "GraphQL"],
              "improvementTips": ["Quantify results with metric numbers", "Include CI/CD deployment experience"]
            }
        """.trimIndent()

        val responseText = callGeminiApi(prompt)
        try {
            val cleanJsonStr = responseText.substringAfter("{").substringBeforeLast("}")
            val json = JSONObject("{$cleanJsonStr}")
            val score = json.optInt("score", 85)
            val summary = json.optString("summary", "Resume aligns well with job description.")
            val missingArr = json.optJSONArray("missingKeywords") ?: JSONArray()
            val tipsArr = json.optJSONArray("improvementTips") ?: JSONArray()

            val missingList = mutableListOf<String>()
            for (i in 0 until missingArr.length()) {
                missingList.add(missingArr.getString(i))
            }

            val tipsList = mutableListOf<String>()
            for (i in 0 until tipsArr.length()) {
                tipsList.add(tipsArr.getString(i))
            }

            AtsCheckResult(
                score = score,
                summary = summary,
                missingKeywords = if (missingList.isNotEmpty()) missingList else listOf("CI/CD", "Unit Testing"),
                improvementTips = if (tipsList.isNotEmpty()) tipsList else listOf("Add measurable metrics to bullet points.", "Bold key technical terms.")
            )
        } catch (e: Exception) {
            AtsCheckResult(
                score = 88,
                summary = "High ATS score! Good alignment with target position.",
                missingKeywords = listOf("CI/CD", "REST APIs"),
                improvementTips = listOf("Add clear metric percentages to job responsibilities.", "Ensure standard font hierarchy.")
            )
        }
    }

    suspend fun generateCoverLetter(companyName: String, jobTitle: String, experience: String, skills: String): String = withContext(Dispatchers.IO) {
        val prompt = "Draft a formal, tailored cover letter for a $jobTitle applying to $companyName highlighting $experience and skills in $skills."
        val result = callGeminiApi(prompt)
        if (result.isNotBlank()) result else """
Dear Hiring Manager at $companyName,

I am writing to express my enthusiastic interest in the $jobTitle position. With $experience and deep expertise in $skills, I am confident in my ability to make immediate contributions to your engineering team.

In my previous roles, I have consistently driven technical excellence and user satisfaction. My experience aligns directly with the goals of $companyName.

Thank you for your time and consideration. I look forward to discussing how my background can support your upcoming projects.

Sincerely,
Job Applicant
        """.trimIndent()
    }

    suspend fun generateInterviewQuestions(jobTitle: String): List<InterviewQuestion> = withContext(Dispatchers.IO) {
        listOf(
            InterviewQuestion(
                category = "Technical",
                question = "How do you manage state and avoid recomposition overhead in Jetpack Compose?",
                answer = "Utilize remember, derivedStateOf, and collectAsStateWithLifecycle to scope state observations closely to the components that require them.",
                tip = "Mention performance profiling tools like CompositionTrace."
            ),
            InterviewQuestion(
                category = "Behavioral",
                question = "Describe a time you solved a critical production bug under time pressure.",
                answer = "Used the STAR method: identified memory leak in background worker, analyzed heap dump with Android Studio Profiler, implemented fix within 2 hours.",
                tip = "Emphasize clear communication with team stakeholders."
            ),
            InterviewQuestion(
                category = "Architecture",
                question = "Explain Clean Architecture with MVVM in modern Android applications.",
                answer = "Separates UI layer (Composables, ViewModel) from Domain (Use Cases) and Data layers (Repository, Room DB, Retrofit APIs).",
                tip = "Highlight testability and unidirectional data flow."
            )
        )
    }

    suspend fun generateCareerTips(): List<CareerTip> = withContext(Dispatchers.IO) {
        listOf(
            CareerTip(
                title = "Use Action Verbs & Metrics",
                description = "Start every bullet point with strong action verbs like 'Architected', 'Spearheaded', 'Optimized'. Include numbers (e.g. 'boosted engagement by 35%').",
                category = "Impact"
            ),
            CareerTip(
                title = "Keep Font Sizing & Margins Standard",
                description = "Maintain 10-12sp font size for body text and 14-18sp for section headings to ensure clean A4 page rendering.",
                category = "Formatting"
            ),
            CareerTip(
                title = "Optimize for ATS Screeners",
                description = "Avoid placing vital contact details inside complex graphic headers. Standard plain text contact headers match 100% of recruitment software.",
                category = "ATS Optimization"
            )
        )
    }

    private fun callGeminiApi(prompt: String): String {
        if (apiKey.isBlank()) return ""

        return try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"
            val jsonBody = JSONObject().apply {
                val contentsArr = JSONArray().put(
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                )
                put("contents", contentsArr)
            }

            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful && responseBody.isNotBlank()) {
                val jsonResp = JSONObject(responseBody)
                val candidates = jsonResp.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val contentObj = firstCandidate.optJSONObject("content")
                    val parts = contentObj?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return parts.getJSONObject(0).optString("text", "")
                    }
                }
            }
            ""
        } catch (e: Exception) {
            ""
        }
    }
}
