package com.example.data.local

import androidx.room.*
import com.example.data.model.ResumeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ResumeDao {
    @Query("SELECT * FROM resumes ORDER BY updatedAt DESC")
    fun getAllResumes(): Flow<List<ResumeEntity>>

    @Query("SELECT * FROM resumes WHERE id = :id")
    suspend fun getResumeById(id: Long): ResumeEntity?

    @Query("SELECT * FROM resumes WHERE isFavorite = 1 ORDER BY updatedAt DESC")
    fun getFavoriteResumes(): Flow<List<ResumeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResume(resume: ResumeEntity): Long

    @Update
    suspend fun updateResume(resume: ResumeEntity)

    @Query("DELETE FROM resumes WHERE id = :id")
    suspend fun deleteResumeById(id: Long)

    @Query("SELECT COUNT(*) FROM resumes")
    fun getResumeCount(): Flow<Int>
}
