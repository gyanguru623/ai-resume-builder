package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cover_letters")
data class CoverLetterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "Cover Letter",
    val companyName: String = "TechCorp Inc.",
    val jobTitle: String = "Senior Mobile Engineer",
    val recipientName: String = "Hiring Manager",
    val content: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
