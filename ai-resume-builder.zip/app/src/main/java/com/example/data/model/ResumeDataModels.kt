package com.example.data.model

import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

data class WorkExperience(
    val id: String = java.util.UUID.randomUUID().toString(),
    val company: String = "",
    val position: String = "",
    val duration: String = "",
    val location: String = "",
    val responsibilities: String = ""
)

data class Education(
    val id: String = java.util.UUID.randomUUID().toString(),
    val school: String = "",
    val degree: String = "",
    val fieldOfStudy: String = "",
    val year: String = "",
    val grade: String = ""
)

data class Project(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String = "",
    val role: String = "",
    val link: String = "",
    val description: String = ""
)

data class Certificate(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "",
    val issuer: String = "",
    val year: String = ""
)

object JsonAdapters {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    fun serializeExperience(list: List<WorkExperience>): String {
        val type = Types.newParameterizedType(List::class.java, WorkExperience::class.java)
        return moshi.adapter<List<WorkExperience>>(type).toJson(list)
    }

    fun deserializeExperience(json: String): List<WorkExperience> {
        if (json.isBlank()) return emptyList()
        return try {
            val type = Types.newParameterizedType(List::class.java, WorkExperience::class.java)
            moshi.adapter<List<WorkExperience>>(type).fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun serializeEducation(list: List<Education>): String {
        val type = Types.newParameterizedType(List::class.java, Education::class.java)
        return moshi.adapter<List<Education>>(type).toJson(list)
    }

    fun deserializeEducation(json: String): List<Education> {
        if (json.isBlank()) return emptyList()
        return try {
            val type = Types.newParameterizedType(List::class.java, Education::class.java)
            moshi.adapter<List<Education>>(type).fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun serializeProjects(list: List<Project>): String {
        val type = Types.newParameterizedType(List::class.java, Project::class.java)
        return moshi.adapter<List<Project>>(type).toJson(list)
    }

    fun deserializeProjects(json: String): List<Project> {
        if (json.isBlank()) return emptyList()
        return try {
            val type = Types.newParameterizedType(List::class.java, Project::class.java)
            moshi.adapter<List<Project>>(type).fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun serializeCertificates(list: List<Certificate>): String {
        val type = Types.newParameterizedType(List::class.java, Certificate::class.java)
        return moshi.adapter<List<Certificate>>(type).toJson(list)
    }

    fun deserializeCertificates(json: String): List<Certificate> {
        if (json.isBlank()) return emptyList()
        return try {
            val type = Types.newParameterizedType(List::class.java, Certificate::class.java)
            moshi.adapter<List<Certificate>>(type).fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun serializeStringList(list: List<String>): String {
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        return moshi.adapter<List<String>>(type).toJson(list)
    }

    fun deserializeStringList(json: String): List<String> {
        if (json.isBlank()) return emptyList()
        return try {
            val type = Types.newParameterizedType(List::class.java, String::class.java)
            moshi.adapter<List<String>>(type).fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
