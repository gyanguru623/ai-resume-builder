package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "resumes")
data class ResumeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "My Resume",
    val targetJobTitle: String = "Software Engineer",
    val userPhotoUri: String = "",
    val name: String = "Alex Morgan",
    val email: String = "alex.morgan@email.com",
    val phone: String = "+1 (555) 234-5678",
    val location: String = "San Francisco, CA",
    val website: String = "alexmorgan.dev",
    val linkedIn: String = "linkedin.com/in/alexmorgan",
    val github: String = "github.com/alexmorgan",
    val portfolio: String = "alexmorgan.portfolio.io",
    val summary: String = "Innovative Software Engineer with 4+ years of experience in Android development, Kotlin, Jetpack Compose, and cloud integrations. Passionate about building high-performance mobile apps with modern user experiences.",
    val workExperienceJson: String = "",
    val educationJson: String = "",
    val skillsJson: String = "",
    val projectsJson: String = "",
    val certificatesJson: String = "",
    val languagesJson: String = "",
    val interestsJson: String = "",
    val templateId: String = "modern_purple",
    val themeColorHex: String = "#6C63FF",
    val fontSize: Float = 12f,
    val fontStyle: String = "Inter",
    val margins: Float = 16f,
    val atsScore: Int = 88,
    val isFavorite: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
