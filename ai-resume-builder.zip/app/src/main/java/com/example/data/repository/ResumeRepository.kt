package com.example.data.repository

import com.example.data.local.CoverLetterDao
import com.example.data.local.ResumeDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class ResumeRepository(
    private val resumeDao: ResumeDao,
    private val coverLetterDao: CoverLetterDao
) {
    val allResumes: Flow<List<ResumeEntity>> = resumeDao.getAllResumes()
    val favoriteResumes: Flow<List<ResumeEntity>> = resumeDao.getFavoriteResumes()
    val resumeCount: Flow<Int> = resumeDao.getResumeCount()
    val allCoverLetters: Flow<List<CoverLetterEntity>> = coverLetterDao.getAllCoverLetters()

    suspend fun getResumeById(id: Long): ResumeEntity? = resumeDao.getResumeById(id)

    suspend fun saveResume(resume: ResumeEntity): Long {
        val updated = resume.copy(updatedAt = System.currentTimeMillis())
        return resumeDao.insertResume(updated)
    }

    suspend fun deleteResume(id: Long) {
        resumeDao.deleteResumeById(id)
    }

    suspend fun duplicateResume(id: Long): Long? {
        val original = resumeDao.getResumeById(id) ?: return null
        val copy = original.copy(
            id = 0,
            title = "${original.title} (Copy)",
            updatedAt = System.currentTimeMillis()
        )
        return resumeDao.insertResume(copy)
    }

    suspend fun toggleFavorite(resume: ResumeEntity) {
        val updated = resume.copy(isFavorite = !resume.isFavorite, updatedAt = System.currentTimeMillis())
        resumeDao.updateResume(updated)
    }

    suspend fun saveCoverLetter(letter: CoverLetterEntity): Long {
        return coverLetterDao.insertCoverLetter(letter.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteCoverLetter(id: Long) {
        coverLetterDao.deleteCoverLetterById(id)
    }

    suspend fun prepopulateIfEmpty() {
        val count = resumeDao.getResumeCount().first()
        if (count == 0) {
            val sampleExperience = listOf(
                WorkExperience(
                    company = "TechSolutions Inc.",
                    position = "Senior Mobile Developer",
                    duration = "Jan 2023 - Present",
                    location = "San Francisco, CA",
                    responsibilities = "• Led development of 4 flagship Android applications using Kotlin, Jetpack Compose, and Coroutines.\n• Reduced app launch time by 35% through custom memory optimization and Room caching.\n• Integrated Gemini AI REST API to deliver smart content summarization for over 200,000 monthly active users."
                ),
                WorkExperience(
                    company = "CloudCore Systems",
                    position = "Android Developer",
                    duration = "Jun 2021 - Dec 2022",
                    location = "San Jose, CA",
                    responsibilities = "• Designed modern Material 3 UI screens with dynamic theme support and accessibility features.\n• Implemented secure offline storage and REST client synchronization using Retrofit and OkHttp."
                )
            )

            val sampleEducation = listOf(
                Education(
                    school = "University of California, Berkeley",
                    degree = "B.S. Computer Science",
                    fieldOfStudy = "Computer Science",
                    year = "2017 - 2021",
                    grade = "3.8/4.0 GPA"
                )
            )

            val sampleProjects = listOf(
                Project(
                    title = "AI Resume Builder",
                    role = "Sole Creator",
                    link = "github.com/alexmorgan/airesume",
                    description = "Android app that generates ATS-friendly resumes using Jetpack Compose and Gemini AI."
                ),
                Project(
                    title = "Crypto Track Compose",
                    role = "Developer",
                    link = "github.com/alexmorgan/cryptotrack",
                    description = "Real-time cryptocurrency portfolio tracker with interactive Material 3 charts."
                )
            )

            val sampleCertificates = listOf(
                Certificate(name = "Google Certified Associate Android Developer", issuer = "Google", year = "2023"),
                Certificate(name = "AWS Certified Developer Associate", issuer = "Amazon Web Services", year = "2022")
            )

            val sampleSkills = listOf("Kotlin", "Jetpack Compose", "Coroutines & Flow", "Room Database", "Retrofit", "Material Design 3", "Git", "CI/CD", "Unit Testing & Robolectric", "Clean Architecture / MVVM")
            val sampleSoftSkills = listOf("Problem Solving", "Team Leadership", "Agile/Scrum", "Communication", "Time Management")
            val sampleLanguages = listOf("English (Native)", "Spanish (Intermediate)", "French (Basic)")

            val resume1 = ResumeEntity(
                title = "Senior_Android_Dev_2026",
                targetJobTitle = "Senior Android Engineer",
                name = "Alex Morgan",
                email = "alex.morgan@devstudio.io",
                phone = "+1 (555) 234-5678",
                location = "San Francisco, CA",
                website = "alexmorgan.dev",
                linkedIn = "linkedin.com/in/alexmorgan",
                github = "github.com/alexmorgan",
                summary = "Results-driven Senior Android Developer with 5+ years of experience building scalable, high-performing mobile applications using Kotlin, Jetpack Compose, and modern clean architecture. Proven track record in AI integration and Material 3 design.",
                workExperienceJson = JsonAdapters.serializeExperience(sampleExperience),
                educationJson = JsonAdapters.serializeEducation(sampleEducation),
                skillsJson = JsonAdapters.serializeStringList(sampleSkills),
                projectsJson = JsonAdapters.serializeProjects(sampleProjects),
                certificatesJson = JsonAdapters.serializeCertificates(sampleCertificates),
                languagesJson = JsonAdapters.serializeStringList(sampleLanguages),
                interestsJson = JsonAdapters.serializeStringList(listOf("Open Source", "UI/UX Design", "Tech Blogging", "Marathon Running")),
                templateId = "modern_purple",
                themeColorHex = "#6C63FF",
                atsScore = 92,
                isFavorite = true
            )

            val resume2 = ResumeEntity(
                title = "FullStack_Developer_ATS",
                targetJobTitle = "Full Stack Engineer",
                name = "Alex Morgan",
                email = "alex.morgan@devstudio.io",
                phone = "+1 (555) 234-5678",
                location = "San Francisco, CA",
                website = "alexmorgan.dev",
                summary = "Versatile Full Stack Mobile Developer proficient in Kotlin, REST APIs, Room DB, and backend integrations. Passionate about automated testing and continuous deliverability.",
                workExperienceJson = JsonAdapters.serializeExperience(sampleExperience.take(1)),
                educationJson = JsonAdapters.serializeEducation(sampleEducation),
                skillsJson = JsonAdapters.serializeStringList(listOf("Kotlin", "Java", "Python", "REST APIs", "Node.js", "SQL", "Git")),
                templateId = "ats_professional",
                themeColorHex = "#00C896",
                atsScore = 85,
                isFavorite = false
            )

            resumeDao.insertResume(resume1)
            resumeDao.insertResume(resume2)

            coverLetterDao.insertCoverLetter(
                CoverLetterEntity(
                    title = "Google Senior Mobile Engineer Cover Letter",
                    companyName = "Google LLC",
                    jobTitle = "Senior Mobile Software Engineer",
                    recipientName = "Engineering Hiring Team",
                    content = "Dear Hiring Team at Google LLC,\n\nI am writing to express my strong enthusiasm for the Senior Mobile Software Engineer position. With over 5 years of experience architecting native Android solutions using Kotlin and Jetpack Compose, I have consistently driven technical excellence and superior user engagement.\n\nIn my recent projects, I integrated Google Gemini AI models to deliver intelligent user interfaces that boosted monthly active user metrics by 35%. I am confident that my deep expertise in modern Android architecture, performance optimization, and intuitive UI design will make an immediate positive impact on your mobile team.\n\nThank you for your time and consideration. I look forward to discussing how my skills align with Google's vision.\n\nSincerely,\nAlex Morgan"
                )
            )
        }
    }
}
