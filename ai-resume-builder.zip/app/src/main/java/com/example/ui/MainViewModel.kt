package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AtsCheckResult
import com.example.ai.CareerTip
import com.example.ai.GeminiAiService
import com.example.ai.InterviewQuestion
import com.example.data.local.AppDatabase
import com.example.data.model.CoverLetterEntity
import com.example.data.model.ResumeEntity
import com.example.data.repository.ResumeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UserProfile(
    val name: String = "Alex Morgan",
    val email: String = "alex.morgan@email.com",
    val isGuest: Boolean = false,
    val isPremium: Boolean = true,
    val profilePhotoUri: String = ""
)

data class AdminSettings(
    val apiKeyOverride: String = "",
    val adsEnabled: Boolean = false,
    val maintenanceMode: Boolean = false,
    val remoteVersion: String = "2.5.0"
)

class MainViewModel(
    application: Application,
    private val customRepository: ResumeRepository? = null,
    private val customAiService: GeminiAiService? = null
) : AndroidViewModel(application) {

    private val repository: ResumeRepository
    private val aiService: GeminiAiService

    private val _resumes = MutableStateFlow<List<ResumeEntity>>(emptyList())
    val resumes: StateFlow<List<ResumeEntity>> = _resumes.asStateFlow()

    private val _coverLetters = MutableStateFlow<List<CoverLetterEntity>>(emptyList())
    val coverLetters: StateFlow<List<CoverLetterEntity>> = _coverLetters.asStateFlow()

    private val _activeResume = MutableStateFlow<ResumeEntity?>(null)
    val activeResume: StateFlow<ResumeEntity?> = _activeResume.asStateFlow()

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _adminSettings = MutableStateFlow(AdminSettings())
    val adminSettings: StateFlow<AdminSettings> = _adminSettings.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _aiLoading = MutableStateFlow(false)
    val aiLoading: StateFlow<Boolean> = _aiLoading.asStateFlow()

    private val _atsResult = MutableStateFlow<AtsCheckResult?>(null)
    val atsResult: StateFlow<AtsCheckResult?> = _atsResult.asStateFlow()

    private val _interviewQuestions = MutableStateFlow<List<InterviewQuestion>>(emptyList())
    val interviewQuestions: StateFlow<List<InterviewQuestion>> = _interviewQuestions.asStateFlow()

    private val _careerTips = MutableStateFlow<List<CareerTip>>(emptyList())
    val careerTips: StateFlow<List<CareerTip>> = _careerTips.asStateFlow()

    init {
        if (customRepository != null) {
            repository = customRepository
        } else {
            val database = AppDatabase.getDatabase(application)
            repository = ResumeRepository(database.resumeDao(), database.coverLetterDao())
        }

        aiService = customAiService ?: GeminiAiService(application.applicationContext)

        viewModelScope.launch {
            repository.prepopulateIfEmpty()
            repository.allResumes.collect { list ->
                _resumes.value = list
                if (_activeResume.value == null && list.isNotEmpty()) {
                    _activeResume.value = list.first()
                }
            }
        }

        viewModelScope.launch {
            repository.allCoverLetters.collect { list ->
                _coverLetters.value = list
            }
        }

        loadCareerTips()
    }

    fun toggleDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
    }

    fun updateUserProfile(name: String, email: String, isGuest: Boolean = false) {
        _userProfile.value = _userProfile.value.copy(
            name = name,
            email = email,
            isGuest = isGuest
        )
    }

    fun updateAdminSettings(newSettings: AdminSettings) {
        _adminSettings.value = newSettings
    }

    fun resetToSeedData() {
        viewModelScope.launch {
            repository.prepopulateIfEmpty()
        }
    }

    fun setActiveResume(resume: ResumeEntity) {
        _activeResume.value = resume
    }

    fun createFullResume(
        resume: ResumeEntity,
        onSaved: (ResumeEntity) -> Unit
    ) {
        viewModelScope.launch {
            val id = repository.saveResume(resume)
            val saved = repository.getResumeById(id) ?: resume.copy(id = id)
            _activeResume.value = saved
            onSaved(saved)
        }
    }

    fun createNewResume(title: String, jobTitle: String, templateId: String = "modern_purple"): ResumeEntity {
        val newResume = ResumeEntity(
            title = title,
            targetJobTitle = jobTitle,
            templateId = templateId,
            name = _userProfile.value.name,
            email = _userProfile.value.email
        )
        viewModelScope.launch {
            val id = repository.saveResume(newResume)
            val saved = repository.getResumeById(id)
            if (saved != null) {
                _activeResume.value = saved
            }
        }
        return newResume
    }

    fun updateActiveResume(updated: ResumeEntity) {
        _activeResume.value = updated
        viewModelScope.launch {
            repository.saveResume(updated)
        }
    }

    fun duplicateResume(id: Long) {
        viewModelScope.launch {
            repository.duplicateResume(id)
        }
    }

    fun deleteResume(id: Long) {
        viewModelScope.launch {
            repository.deleteResume(id)
            if (_activeResume.value?.id == id) {
                _activeResume.value = _resumes.value.firstOrNull { it.id != id }
            }
        }
    }

    fun toggleFavorite(resume: ResumeEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(resume)
        }
    }

    fun saveCoverLetter(companyName: String, jobTitle: String, content: String) {
        viewModelScope.launch {
            repository.saveCoverLetter(
                CoverLetterEntity(
                    title = "$companyName Cover Letter",
                    companyName = companyName,
                    jobTitle = jobTitle,
                    content = content
                )
            )
        }
    }

    fun deleteCoverLetter(id: Long) {
        viewModelScope.launch {
            repository.deleteCoverLetter(id)
        }
    }

    fun generateSummaryWithAi(jobTitle: String, exp: String, skills: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            _aiLoading.value = true
            val summary = aiService.generateSummary(jobTitle, exp, skills)
            _aiLoading.value = false
            onResult(summary)
        }
    }

    fun improveBulletWithAi(original: String, tone: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            _aiLoading.value = true
            val improved = aiService.improveBulletPoint(original, tone)
            _aiLoading.value = false
            onResult(improved)
        }
    }

    fun suggestSkillsWithAi(jobTitle: String, onResult: (List<String>) -> Unit) {
        viewModelScope.launch {
            _aiLoading.value = true
            val skills = aiService.suggestSkills(jobTitle)
            _aiLoading.value = false
            onResult(skills)
        }
    }

    fun runAtsCheck(resumeText: String, jobDescription: String) {
        viewModelScope.launch {
            _aiLoading.value = true
            val result = aiService.checkAtsScore(resumeText, jobDescription)
            _atsResult.value = result
            _aiLoading.value = false
        }
    }

    fun generateCoverLetterWithAi(company: String, jobTitle: String, exp: String, skills: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            _aiLoading.value = true
            val letter = aiService.generateCoverLetter(company, jobTitle, exp, skills)
            _aiLoading.value = false
            onResult(letter)
        }
    }

    fun loadInterviewQuestions(jobTitle: String) {
        viewModelScope.launch {
            _aiLoading.value = true
            val list = aiService.generateInterviewQuestions(jobTitle)
            _interviewQuestions.value = list
            _aiLoading.value = false
        }
    }

    private fun loadCareerTips() {
        viewModelScope.launch {
            val tips = aiService.generateCareerTips()
            _careerTips.value = tips
        }
    }
}
