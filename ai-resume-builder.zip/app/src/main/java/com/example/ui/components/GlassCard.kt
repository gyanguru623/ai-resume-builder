package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.GlassBorderLight
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryPurple

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    backgroundColor: Color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
    borderColor: Color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
    borderWidth: Dp = 1.dp,
    elevation: Dp = 2.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val clickableModifier = if (onClick != null) {
        modifier.clickable { onClick() }
    } else {
        modifier
    }

    Surface(
        modifier = clickableModifier
            .shadow(
                elevation = elevation,
                shape = shape,
                ambientColor = PrimaryPurple.copy(alpha = 0.1f),
                spotColor = PrimaryPurple.copy(alpha = 0.15f)
            )
            .border(
                border = BorderStroke(borderWidth, borderColor),
                shape = shape
            ),
        shape = shape,
        color = backgroundColor,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        Column(content = content)
    }
}

@Composable
fun GlassHeroCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(PrimaryPurple, SecondaryPurple)
                )
            )
            .border(
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                shape = shape
            )
            .shadow(
                elevation = 8.dp,
                shape = shape,
                spotColor = PrimaryPurple.copy(alpha = 0.4f)
            )
    ) {
        // Decorative glowing frosted circles
        Box(
            modifier = Modifier
                .size(140.dp)
                .offset(x = (-30).dp, y = (-30).dp)
                .background(Color.White.copy(alpha = 0.12f), shape = RoundedCornerShape(100.dp))
        )
        Box(
            modifier = Modifier
                .size(180.dp)
                .align(Alignment.BottomEnd)
                .offset(x = 40.dp, y = 40.dp)
                .background(Color.White.copy(alpha = 0.08f), shape = RoundedCornerShape(100.dp))
        )

        content()
    }
}

@Composable
fun FrostedBadge(
    text: String,
    modifier: Modifier = Modifier,
    badgeColor: Color = PrimaryPurple,
    textColor: Color = badgeColor
) {
    Surface(
        modifier = modifier,
        color = badgeColor.copy(alpha = 0.12f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.2f))
    ) {
        Text(
            text = text,
            color = textColor,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}
