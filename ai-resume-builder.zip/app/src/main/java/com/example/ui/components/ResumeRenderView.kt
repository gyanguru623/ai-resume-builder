package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.JsonAdapters
import com.example.data.model.ResumeEntity
import com.example.ui.templates.ResumeTemplateCatalog

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ResumeRenderView(
    resume: ResumeEntity,
    modifier: Modifier = Modifier,
    customColorHex: String? = null
) {
    val template = ResumeTemplateCatalog.getTemplateById(resume.templateId)
    val colorHex = customColorHex ?: resume.themeColorHex.ifBlank { template.primaryColorHex }
    val primaryColor = try {
        Color(android.graphics.Color.parseColor(colorHex))
    } catch (e: Exception) {
        Color(0xFF6C63FF)
    }

    val experiences = JsonAdapters.deserializeExperience(resume.workExperienceJson)
    val educations = JsonAdapters.deserializeEducation(resume.educationJson)
    val skills = JsonAdapters.deserializeStringList(resume.skillsJson)
    val projects = JsonAdapters.deserializeProjects(resume.projectsJson)
    val certificates = JsonAdapters.deserializeCertificates(resume.certificatesJson)
    val languages = JsonAdapters.deserializeStringList(resume.languagesJson)

    val fontFamily = when (resume.fontStyle) {
        "Serif" -> FontFamily.Serif
        "Monospace", "Source Code Pro" -> FontFamily.Monospace
        "Cursive" -> FontFamily.Cursive
        else -> FontFamily.Default
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(resume.margins.dp.coerceIn(8.dp, 24.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header Section
            when (template.layoutType) {
                "split_left" -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (resume.userPhotoUri.isNotBlank()) {
                            AsyncImage(
                                model = resume.userPhotoUri,
                                contentDescription = "Passport Profile Photo",
                                modifier = Modifier
                                    .size(width = 68.dp, height = 82.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(2.dp, primaryColor, RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = resume.name.ifBlank { "Your Name" },
                                fontSize = (resume.fontSize + 10).sp,
                                fontWeight = FontWeight.Bold,
                                color = primaryColor,
                                fontFamily = fontFamily
                            )
                            Text(
                                text = resume.targetJobTitle.ifBlank { "Job Title" },
                                fontSize = (resume.fontSize + 2).sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.Gray,
                                fontFamily = fontFamily
                            )
                        }
                    }
                }
                "header_accent" -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(primaryColor, RoundedCornerShape(8.dp))
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (resume.userPhotoUri.isNotBlank()) {
                            AsyncImage(
                                model = resume.userPhotoUri,
                                contentDescription = "Passport Profile Photo",
                                modifier = Modifier
                                    .size(width = 64.dp, height = 78.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(2.dp, Color.White, RoundedCornerShape(6.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = resume.name.ifBlank { "Your Name" },
                                fontSize = (resume.fontSize + 12).sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontFamily = fontFamily
                            )
                            Text(
                                text = resume.targetJobTitle.ifBlank { "Job Title" },
                                fontSize = (resume.fontSize + 2).sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White.copy(alpha = 0.9f),
                                fontFamily = fontFamily
                            )
                        }
                    }
                }
                else -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (resume.userPhotoUri.isNotBlank()) {
                            AsyncImage(
                                model = resume.userPhotoUri,
                                contentDescription = "Passport Profile Photo",
                                modifier = Modifier
                                    .size(width = 68.dp, height = 82.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(2.dp, primaryColor, RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = resume.name.ifBlank { "Your Name" },
                                fontSize = (resume.fontSize + 12).sp,
                                fontWeight = FontWeight.Bold,
                                color = primaryColor,
                                fontFamily = fontFamily
                            )
                            Text(
                                text = resume.targetJobTitle.ifBlank { "Job Title" },
                                fontSize = (resume.fontSize + 2).sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.DarkGray,
                                fontFamily = fontFamily
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Contact Bar
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (resume.email.isNotBlank()) ContactBadge(Icons.Default.Email, resume.email, primaryColor, fontFamily)
                if (resume.phone.isNotBlank()) ContactBadge(Icons.Default.Phone, resume.phone, primaryColor, fontFamily)
                if (resume.location.isNotBlank()) ContactBadge(Icons.Default.LocationOn, resume.location, primaryColor, fontFamily)
                if (resume.linkedIn.isNotBlank()) ContactBadge(Icons.Default.Link, resume.linkedIn, primaryColor, fontFamily)
                if (resume.github.isNotBlank()) ContactBadge(Icons.Default.Code, resume.github, primaryColor, fontFamily)
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 14.dp),
                color = primaryColor.copy(alpha = 0.3f),
                thickness = 1.dp
            )

            // Professional Summary
            if (resume.summary.isNotBlank()) {
                SectionHeader("PROFESSIONAL SUMMARY", primaryColor, fontFamily)
                Text(
                    text = resume.summary,
                    fontSize = resume.fontSize.sp,
                    color = Color.DarkGray,
                    fontFamily = fontFamily,
                    lineHeight = (resume.fontSize + 6).sp,
                    modifier = Modifier.padding(bottom = 14.dp)
                )
            }

            // Work Experience
            if (experiences.isNotEmpty()) {
                SectionHeader("WORK EXPERIENCE", primaryColor, fontFamily)
                experiences.forEach { exp ->
                    Column(modifier = Modifier.padding(bottom = 12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = exp.position.ifBlank { "Position" },
                                fontWeight = FontWeight.Bold,
                                fontSize = (resume.fontSize + 1).sp,
                                color = Color.Black,
                                fontFamily = fontFamily
                            )
                            Text(
                                text = exp.duration,
                                fontSize = (resume.fontSize - 1).sp,
                                color = primaryColor,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = fontFamily
                            )
                        }
                        Text(
                            text = "${exp.company} ${if (exp.location.isNotBlank()) "• ${exp.location}" else ""}",
                            fontSize = resume.fontSize.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Medium,
                            fontFamily = fontFamily
                        )
                        if (exp.responsibilities.isNotBlank()) {
                            Text(
                                text = exp.responsibilities,
                                fontSize = (resume.fontSize - 1).sp,
                                color = Color.DarkGray,
                                fontFamily = fontFamily,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }

            // Education
            if (educations.isNotEmpty()) {
                SectionHeader("EDUCATION", primaryColor, fontFamily)
                educations.forEach { edu ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${edu.degree} - ${edu.school}",
                                fontWeight = FontWeight.Bold,
                                fontSize = resume.fontSize.sp,
                                color = Color.Black,
                                fontFamily = fontFamily
                            )
                            if (edu.grade.isNotBlank()) {
                                Text(
                                    text = "Grade: ${edu.grade}",
                                    fontSize = (resume.fontSize - 1).sp,
                                    color = Color.Gray,
                                    fontFamily = fontFamily
                                )
                            }
                        }
                        Text(
                            text = edu.year,
                            fontSize = (resume.fontSize - 1).sp,
                            color = primaryColor,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = fontFamily
                        )
                    }
                }
            }

            // Skills
            if (skills.isNotEmpty()) {
                SectionHeader("CORE SKILLS", primaryColor, fontFamily)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    skills.forEach { skill ->
                        Surface(
                            color = primaryColor.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = skill,
                                fontSize = (resume.fontSize - 1).sp,
                                color = primaryColor,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontFamily = fontFamily
                            )
                        }
                    }
                }
            }

            // Projects
            if (projects.isNotEmpty()) {
                SectionHeader("KEY PROJECTS", primaryColor, fontFamily)
                projects.forEach { proj ->
                    Column(modifier = Modifier.padding(bottom = 8.dp)) {
                        Text(
                            text = "${proj.title} ${if (proj.role.isNotBlank()) "(${proj.role})" else ""}",
                            fontWeight = FontWeight.Bold,
                            fontSize = resume.fontSize.sp,
                            color = Color.Black,
                            fontFamily = fontFamily
                        )
                        if (proj.description.isNotBlank()) {
                            Text(
                                text = proj.description,
                                fontSize = (resume.fontSize - 1).sp,
                                color = Color.DarkGray,
                                fontFamily = fontFamily
                            )
                        }
                    }
                }
            }

            // Certificates
            if (certificates.isNotEmpty()) {
                SectionHeader("CERTIFICATIONS", primaryColor, fontFamily)
                certificates.forEach { cert ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "• ${cert.name} (${cert.issuer})",
                            fontSize = (resume.fontSize - 1).sp,
                            color = Color.DarkGray,
                            fontFamily = fontFamily
                        )
                        Text(
                            text = cert.year,
                            fontSize = (resume.fontSize - 1).sp,
                            color = primaryColor,
                            fontFamily = fontFamily
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, color: Color, fontFamily: FontFamily) {
    Column(modifier = Modifier.padding(top = 10.dp, bottom = 8.dp)) {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            letterSpacing = 1.sp,
            fontFamily = fontFamily
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(color.copy(alpha = 0.4f))
        )
    }
}

@Composable
private fun ContactBadge(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, color: Color, fontFamily: FontFamily) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            fontSize = 11.sp,
            color = Color.DarkGray,
            fontFamily = fontFamily
        )
    }
}
