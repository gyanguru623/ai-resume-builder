package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.compose.ui.platform.LocalContext
import android.app.Activity
import com.example.ads.AdManager
import com.example.data.model.*
import com.example.ui.MainViewModel
import com.example.ui.templates.ResumeTemplateCatalog
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.PrimaryPurple

@Composable
fun CreateResumeTab(
    viewModel: MainViewModel,
    onFinishCreate: (ResumeEntity) -> Unit
) {
    val aiLoading by viewModel.aiLoading.collectAsState()

    var currentStep by remember { mutableIntStateOf(1) }

    // Form States
    var userPhotoUri by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var targetJobTitle by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            userPhotoUri = uri.toString()
        }
    }
    var phone by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var website by remember { mutableStateOf("") }
    var linkedIn by remember { mutableStateOf("") }
    var github by remember { mutableStateOf("") }

    var summary by remember { mutableStateOf("") }

    var experiences by remember {
        mutableStateOf(listOf(WorkExperience()))
    }

    var educations by remember {
        mutableStateOf(listOf(Education()))
    }

    var skillInput by remember { mutableStateOf("") }
    var selectedTemplateId by remember { mutableStateOf("modern_purple") }

    val context = LocalContext.current
    val activity = context as? Activity

    Scaffold(
        topBar = {
            Surface(tonalElevation = 2.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Step $currentStep of 6",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryPurple
                        )
                        Text(
                            text = when (currentStep) {
                                1 -> "Personal Details"
                                2 -> "AI Summary"
                                3 -> "Work Experience"
                                4 -> "Education"
                                5 -> "Skills & Extras"
                                else -> "Style Selection"
                            },
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { currentStep / 6f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = PrimaryPurple,
                        trackColor = PrimaryPurple.copy(alpha = 0.2f)
                    )
                }
            }
        },
        bottomBar = {
            Surface(tonalElevation = 4.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (currentStep > 1) {
                        OutlinedButton(
                            onClick = { currentStep-- },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Back")
                        }
                    } else {
                        Spacer(modifier = Modifier.width(80.dp))
                    }

                    Button(
                        onClick = {
                            if (currentStep < 6) {
                                currentStep++
                            } else {
                                val skillsList = skillInput.split(",").map { it.trim() }.filter { it.isNotBlank() }
                                val newResume = ResumeEntity(
                                    title = "${name.replace(" ", "_")}_Resume",
                                    targetJobTitle = targetJobTitle,
                                    userPhotoUri = userPhotoUri,
                                    templateId = selectedTemplateId,
                                    name = name,
                                    email = email,
                                    phone = phone,
                                    location = location,
                                    website = website,
                                    linkedIn = linkedIn,
                                    github = github,
                                    summary = summary,
                                    workExperienceJson = JsonAdapters.serializeExperience(experiences),
                                    educationJson = JsonAdapters.serializeEducation(educations),
                                    skillsJson = JsonAdapters.serializeStringList(skillsList)
                                )
                                viewModel.createFullResume(newResume) { saved ->
                                    if (activity != null) {
                                        AdManager.showInterstitialAd(activity) {
                                            onFinishCreate(saved)
                                        }
                                    } else {
                                        onFinishCreate(saved)
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (currentStep == 6) "Finish & Save" else "Next Step")
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            when (currentStep) {
                1 -> {
                    Text("Personal Details", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Fill in your primary contact information", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            if (userPhotoUri.isNotBlank()) {
                                AsyncImage(
                                    model = userPhotoUri,
                                    contentDescription = "Passport Photo",
                                    modifier = Modifier
                                        .size(width = 60.dp, height = 75.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(2.dp, PrimaryPurple, RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(width = 60.dp, height = 75.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(PrimaryPurple.copy(alpha = 0.1f))
                                        .border(1.dp, PrimaryPurple.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.AddAPhoto, contentDescription = null, tint = PrimaryPurple)
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text("Passport Size Photo", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Add a photo for ATS & modern templates", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { photoPickerLauncher.launch("image/*") },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(if (userPhotoUri.isBlank()) "Upload Photo" else "Change", fontSize = 12.sp)
                                    }
                                    if (userPhotoUri.isNotBlank()) {
                                        OutlinedButton(
                                            onClick = { userPhotoUri = "" },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("Remove", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Full Name *") },
                        placeholder = { Text("e.g. John Doe") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = targetJobTitle,
                        onValueChange = { targetJobTitle = it },
                        label = { Text("Target Job Title *") },
                        placeholder = { Text("e.g. Software Engineer") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address *") },
                        placeholder = { Text("e.g. john@example.com") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone Number") },
                        placeholder = { Text("e.g. +91 98765 43210") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("City, Country") },
                        placeholder = { Text("e.g. Mumbai, India") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = linkedIn,
                        onValueChange = { linkedIn = it },
                        label = { Text("LinkedIn Profile URL") },
                        placeholder = { Text("e.g. linkedin.com/in/johndoe") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = github,
                        onValueChange = { github = it },
                        label = { Text("GitHub / Portfolio URL") },
                        placeholder = { Text("e.g. github.com/johndoe") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                2 -> {
                    Text("Professional Summary", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Write a high-impact summary or generate one using Gemini AI", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))

                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.elevatedCardColors(containerColor = PrimaryPurple.copy(alpha = 0.08f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = PrimaryPurple)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("AI Summary Generator", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PrimaryPurple)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Generate an ATS-tailored summary automatically based on your job title ($targetJobTitle).", fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    viewModel.generateSummaryWithAi(targetJobTitle, "4 years", skillInput) { generated ->
                                        summary = generated
                                    }
                                },
                                enabled = !aiLoading,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                if (aiLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Generating...")
                                } else {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Generate with AI")
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = summary,
                        onValueChange = { summary = it },
                        label = { Text("Summary Text") },
                        placeholder = { Text("Write your career summary or tap 'Generate with AI'...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                3 -> {
                    Text("Work Experience", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Add your relevant career experience", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))

                    experiences.forEachIndexed { index, exp ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 14.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Experience #${index + 1}", fontWeight = FontWeight.Bold, color = PrimaryPurple)
                                    if (experiences.size > 1) {
                                        IconButton(onClick = {
                                            experiences = experiences.filterIndexed { i, _ -> i != index }
                                        }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = exp.company,
                                    onValueChange = { newComp ->
                                        experiences = experiences.mapIndexed { i, e -> if (i == index) e.copy(company = newComp) else e }
                                    },
                                    label = { Text("Company Name") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = exp.position,
                                    onValueChange = { newPos ->
                                        experiences = experiences.mapIndexed { i, e -> if (i == index) e.copy(position = newPos) else e }
                                    },
                                    label = { Text("Job Position") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = exp.duration,
                                    onValueChange = { newDur ->
                                        experiences = experiences.mapIndexed { i, e -> if (i == index) e.copy(duration = newDur) else e }
                                    },
                                    label = { Text("Duration (e.g. 2022 - Present)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = exp.responsibilities,
                                    onValueChange = { newResp ->
                                        experiences = experiences.mapIndexed { i, e -> if (i == index) e.copy(responsibilities = newResp) else e }
                                    },
                                    label = { Text("Bullet Points / Responsibilities") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(110.dp),
                                    shape = RoundedCornerShape(10.dp)
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                TextButton(
                                    onClick = {
                                        viewModel.improveBulletWithAi(exp.responsibilities, "Professional") { improved ->
                                            experiences = experiences.mapIndexed { i, e -> if (i == index) e.copy(responsibilities = improved) else e }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("AI Rewrite Bullets", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = { experiences = experiences + WorkExperience() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Another Experience")
                    }
                }

                4 -> {
                    Text("Education", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Add your academic credentials", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))

                    educations.forEachIndexed { index, edu ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 14.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Education #${index + 1}", fontWeight = FontWeight.Bold, color = PrimaryPurple)
                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = edu.school,
                                    onValueChange = { valNew ->
                                        educations = educations.mapIndexed { i, e -> if (i == index) e.copy(school = valNew) else e }
                                    },
                                    label = { Text("College / University Name") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = edu.degree,
                                    onValueChange = { valNew ->
                                        educations = educations.mapIndexed { i, e -> if (i == index) e.copy(degree = valNew) else e }
                                    },
                                    label = { Text("Degree (e.g. B.S. Computer Science)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = edu.year,
                                    onValueChange = { valNew ->
                                        educations = educations.mapIndexed { i, e -> if (i == index) e.copy(year = valNew) else e }
                                    },
                                    label = { Text("Year (e.g. 2018 - 2022)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = { educations = educations + Education() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Education")
                    }
                }

                5 -> {
                    Text("Skills & Extras", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Comma-separated core skills for recruiter keyword matching", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Core Technical Skills", fontWeight = FontWeight.Bold)
                        TextButton(
                            onClick = {
                                viewModel.suggestSkillsWithAi(targetJobTitle) { suggestedList ->
                                    skillInput = suggestedList.joinToString(", ")
                                }
                            }
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("AI Skill Suggest", fontSize = 12.sp)
                        }
                    }

                    OutlinedTextField(
                        value = skillInput,
                        onValueChange = { skillInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                6 -> {
                    Text("Choose Resume Template Style", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Select from 50+ ATS templates", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))

                    ResumeTemplateCatalog.templates.take(12).forEach { tmpl ->
                        val isSelected = tmpl.id == selectedTemplateId
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp)
                                .clickable { selectedTemplateId = tmpl.id },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) PrimaryPurple.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                            ),
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, PrimaryPurple) else null
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(tmpl.name, fontWeight = FontWeight.Bold)
                                    Text("${tmpl.category} • ${tmpl.previewBadge}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = "Selected", tint = PrimaryPurple)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
