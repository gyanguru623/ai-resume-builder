package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ResumeEntity
import com.example.ui.MainViewModel
import com.example.ui.theme.PrimaryPurple

enum class DashboardTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    RESUMES("My Files", Icons.Default.Folder),
    CREATE("Create", Icons.Default.Add),
    ATS("ATS Check", Icons.Default.FactCheck),
    SETTINGS("Settings", Icons.Default.Settings)
}

@Composable
fun MainDashboardScreen(
    viewModel: MainViewModel,
    onEditResume: (ResumeEntity) -> Unit,
    onOpenPdfExport: (ResumeEntity) -> Unit,
    onNavigateToAtsChecker: () -> Unit,
    onNavigateToCoverLetter: () -> Unit,
    onNavigateToInterview: () -> Unit,
    onNavigateToCareerTips: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(DashboardTab.HOME) }

    Scaffold(
        bottomBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                tonalElevation = 8.dp,
                shadowElevation = 12.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .height(68.dp)
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DashboardTab.values().forEach { tab ->
                        val isSelected = selectedTab == tab

                        if (tab == DashboardTab.CREATE) {
                            // Elevated Center Floating (+) Button
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .shadow(6.dp, CircleShape, spotColor = PrimaryPurple.copy(alpha = 0.5f))
                                    .background(PrimaryPurple, CircleShape)
                                    .border(2.dp, Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                IconButton(
                                    onClick = { selectedTab = tab },
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Create",
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        } else {
                            IconButton(
                                onClick = { selectedTab = tab },
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.label,
                                        tint = if (isSelected) PrimaryPurple else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = tab.label,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) PrimaryPurple else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                DashboardTab.HOME -> HomeTab(
                    viewModel = viewModel,
                    onNavigateToCreate = { selectedTab = DashboardTab.CREATE },
                    onNavigateToResumes = { selectedTab = DashboardTab.RESUMES },
                    onNavigateToAtsChecker = onNavigateToAtsChecker,
                    onNavigateToCoverLetter = onNavigateToCoverLetter,
                    onNavigateToInterview = onNavigateToInterview,
                    onNavigateToCareerTips = onNavigateToCareerTips,
                    onNavigateToSettings = onNavigateToSettings,
                    onEditResume = onEditResume,
                    onOpenPdfExport = onOpenPdfExport
                )
                DashboardTab.CREATE -> CreateResumeTab(
                    viewModel = viewModel,
                    onFinishCreate = { created ->
                        onEditResume(created)
                    }
                )
                DashboardTab.RESUMES -> ResumesTab(
                    viewModel = viewModel,
                    onEditResume = onEditResume,
                    onOpenPdfExport = onOpenPdfExport,
                    onCreateNew = { selectedTab = DashboardTab.CREATE }
                )
                DashboardTab.ATS -> AtsCheckerScreen(
                    viewModel = viewModel,
                    onBack = { selectedTab = DashboardTab.HOME }
                )
                DashboardTab.SETTINGS -> SettingsScreen(
                    viewModel = viewModel,
                    onBack = { selectedTab = DashboardTab.HOME }
                )
            }
        }
    }
}
