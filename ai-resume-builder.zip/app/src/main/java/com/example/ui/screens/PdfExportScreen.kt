package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.app.Activity
import com.example.ads.AdManager
import com.example.ads.BannerAdView
import com.example.data.model.JsonAdapters
import com.example.data.model.ResumeEntity
import com.example.ui.MainViewModel
import com.example.ui.components.ResumeRenderView
import com.example.ui.theme.PrimaryPurple

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfExportScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activeResume by viewModel.activeResume.collectAsState()
    var activeWebView by remember { mutableStateOf<WebView?>(null) }

    if (activeResume == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No resume selected")
        }
        return
    }

    val resume = activeResume!!

    fun generateResumeHtml(resume: ResumeEntity): String {
        val experiences = JsonAdapters.deserializeExperience(resume.workExperienceJson)
        val educations = JsonAdapters.deserializeEducation(resume.educationJson)
        val skills = JsonAdapters.deserializeStringList(resume.skillsJson)
        val projects = JsonAdapters.deserializeProjects(resume.projectsJson)
        val certificates = JsonAdapters.deserializeCertificates(resume.certificatesJson)
        val colorHex = resume.themeColorHex.ifBlank { "#6C63FF" }

        val photoHtml = if (resume.userPhotoUri.isNotBlank()) {
            """<img src="${resume.userPhotoUri}" style="width:70px; height:85px; object-fit:cover; border-radius:6px; border:2px solid $colorHex; float:right; margin-left:15px;"/>"""
        } else ""

        val contactsList = listOfNotNull(
            if (resume.email.isNotBlank()) "Email: ${resume.email}" else null,
            if (resume.phone.isNotBlank()) "Phone: ${resume.phone}" else null,
            if (resume.location.isNotBlank()) "Location: ${resume.location}" else null,
            if (resume.linkedIn.isNotBlank()) "LinkedIn: ${resume.linkedIn}" else null,
            if (resume.github.isNotBlank()) "GitHub: ${resume.github}" else null
        )
        val contactsHtml = contactsList.joinToString(" &nbsp;|&nbsp; ")

        val expHtml = if (experiences.isNotEmpty()) {
            """<div class="section-title">WORK EXPERIENCE</div>""" +
            experiences.joinToString("") { exp ->
                """<div class="item">
                    <div class="item-header">
                        <strong>${exp.position}</strong> — <span>${exp.company}</span>
                        <span class="date">${exp.duration}</span>
                    </div>
                    ${if (exp.responsibilities.isNotBlank()) "<p>${exp.responsibilities.replace("\n", "<br/>")}</p>" else ""}
                </div>"""
            }
        } else ""

        val eduHtml = if (educations.isNotEmpty()) {
            """<div class="section-title">EDUCATION</div>""" +
            educations.joinToString("") { edu ->
                """<div class="item">
                    <div class="item-header">
                        <strong>${edu.degree}</strong> — <span>${edu.school}</span>
                        <span class="date">${edu.year}</span>
                    </div>
                    ${if (edu.grade.isNotBlank()) "<div>Grade: ${edu.grade}</div>" else ""}
                </div>"""
            }
        } else ""

        val skillsHtml = if (skills.isNotEmpty()) {
            """<div class="section-title">SKILLS</div>
            <div class="skills-container">
                ${skills.joinToString("") { "<span class='skill-badge'>$it</span>" }}
            </div>"""
        } else ""

        val projHtml = if (projects.isNotEmpty()) {
            """<div class="section-title">KEY PROJECTS</div>""" +
            projects.joinToString("") { proj ->
                """<div class="item">
                    <strong>${proj.title}</strong> ${if (proj.role.isNotBlank()) "(${proj.role})" else ""}
                    <p>${proj.description}</p>
                </div>"""
            }
        } else ""

        val certHtml = if (certificates.isNotEmpty()) {
            """<div class="section-title">CERTIFICATIONS</div>""" +
            certificates.joinToString("") { cert ->
                """<div class="item-header">
                    <span>• ${cert.name} (${cert.issuer})</span>
                    <span class="date">${cert.year}</span>
                </div>"""
            }
        } else ""

        return """
            <!DOCTYPE html>
            <html>
            <head>
            <meta charset="utf-8">
            <style>
                body { font-family: 'Helvetica Neue', Arial, sans-serif; padding: 24px; color: #222; max-width: 800px; margin: 0 auto; line-height: 1.4; }
                h1 { color: $colorHex; margin: 0 0 4px 0; font-size: 24px; }
                h3 { color: #555; margin: 0 0 10px 0; font-size: 15px; font-weight: normal; }
                .contacts { font-size: 11px; color: #555; margin-bottom: 14px; }
                .section-title { color: $colorHex; font-size: 13px; font-weight: bold; border-bottom: 2px solid $colorHex; padding-bottom: 3px; margin-top: 16px; margin-bottom: 8px; letter-spacing: 0.5px; }
                .item { margin-bottom: 10px; font-size: 12px; }
                .item-header { display: flex; justify-content: space-between; margin-bottom: 2px; }
                .date { color: $colorHex; font-weight: bold; font-size: 11px; }
                p { margin: 4px 0; font-size: 12px; color: #444; }
                .skills-container { display: flex; flex-wrap: wrap; gap: 6px; }
                .skill-badge { background: rgba(108, 99, 255, 0.1); color: $colorHex; border: 1px solid rgba(108, 99, 255, 0.3); padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
            </style>
            </head>
            <body>
                $photoHtml
                <h1>${resume.name.ifBlank { "Resume" }}</h1>
                <h3>${resume.targetJobTitle}</h3>
                <div class="contacts">$contactsHtml</div>
                ${if (resume.summary.isNotBlank()) "<div class='section-title'>PROFESSIONAL SUMMARY</div><p>${resume.summary.replace("\n", "<br/>")}</p>" else ""}
                $expHtml
                $eduHtml
                $skillsHtml
                $projHtml
                $certHtml
            </body>
            </html>
        """.trimIndent()
    }

    fun triggerPrint() {
        try {
            val webView = WebView(context)
            webView.settings.javaScriptEnabled = true
            val htmlContent = generateResumeHtml(resume)

            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    try {
                        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                        val jobName = "${resume.name.ifBlank { "Resume" }.replace(" ", "_")}_Resume"
                        val printAdapter = view.createPrintDocumentAdapter(jobName)
                        printManager?.print(jobName, printAdapter, PrintAttributes.Builder().build())
                    } catch (e: Exception) {
                        Toast.makeText(context, "Print Error: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
            activeWebView = webView
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to launch PDF generator: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun saveToPhoneStorage() {
        val activity = context as? Activity
        if (activity != null) {
            AdManager.showInterstitialAd(activity) {
                triggerPrint()
                Toast.makeText(context, "Select 'Save as PDF' from top printer dropdown to save to Phone Storage", Toast.LENGTH_LONG).show()
            }
        } else {
            triggerPrint()
            Toast.makeText(context, "Select 'Save as PDF' from top printer dropdown to save to Phone Storage", Toast.LENGTH_LONG).show()
        }
    }

    fun triggerShare() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "${resume.name} - ${resume.targetJobTitle} Resume")
            putExtra(
                Intent.EXTRA_TEXT,
                "${resume.name}\n${resume.targetJobTitle}\nEmail: ${resume.email}\nPhone: ${resume.phone}\n\nSUMMARY:\n${resume.summary}\n\nGenerated via Resume Studio AI"
            )
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share Resume"))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PDF Preview & Download", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 6.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { saveToPhoneStorage() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save PDF to Phone Storage", fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { triggerShare() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share")
                        }

                        OutlinedButton(
                            onClick = { triggerPrint() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Print")
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = PrimaryPurple.copy(alpha = 0.1f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = PrimaryPurple)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Tap 'Save PDF to Phone Storage' to save your resume directly to your device Downloads folder.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "A4 Document Preview",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            ResumeRenderView(resume = resume)

            Spacer(modifier = Modifier.height(16.dp))

            BannerAdView(modifier = Modifier.fillMaxWidth())

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

