package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.JsonAdapters
import com.example.data.model.ResumeEntity
import com.example.ui.MainViewModel
import com.example.ui.components.ResumeRenderView
import com.example.ui.templates.ResumeTemplateCatalog
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.PrimaryPurple

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResumeEditorScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onOpenExport: () -> Unit
) {
    val activeResume by viewModel.activeResume.collectAsState()
    if (activeResume == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    var currentResume by remember(activeResume?.id) { mutableStateOf(activeResume!!) }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Live Preview, 1: Template, 2: Sections, 3: Style

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val updated = currentResume.copy(userPhotoUri = uri.toString())
            currentResume = updated
            viewModel.updateActiveResume(updated)
        }
    }

    val themeColors = listOf("#6C63FF", "#00C896", "#1E293B", "#2563EB", "#D97706", "#DC2626", "#7C3AED", "#059669")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Resume Editor", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    Button(
                        onClick = onOpenExport,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 6.dp) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Preview") },
                        icon = { Icon(Icons.Default.Visibility, contentDescription = null) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Template") },
                        icon = { Icon(Icons.Default.Style, contentDescription = null) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Sections") },
                        icon = { Icon(Icons.Default.Edit, contentDescription = null) }
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = { Text("Style") },
                        icon = { Icon(Icons.Default.Palette, contentDescription = null) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> {
                    // Live Render Preview
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        Surface(
                            color = AccentGreen.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AccentGreen)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Live Auto-Saved Preview", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AccentGreen)
                                    Text("ATS Score: ${currentResume.atsScore}/100 • Changes update in real-time", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        ResumeRenderView(resume = currentResume)
                    }
                }

                1 -> {
                    // Template Selector
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        Text("Select Resume Template", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))

                        ResumeTemplateCatalog.templates.forEach { tmpl ->
                            val isSelected = tmpl.id == currentResume.templateId
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 10.dp)
                                    .clickable {
                                        val updated = currentResume.copy(templateId = tmpl.id, themeColorHex = tmpl.primaryColorHex)
                                        currentResume = updated
                                        viewModel.updateActiveResume(updated)
                                    },
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) PrimaryPurple.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                                ),
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, PrimaryPurple) else null
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(tmpl.name, fontWeight = FontWeight.Bold)
                                        Text("${tmpl.category} • ${tmpl.previewBadge}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = "Selected", tint = PrimaryPurple)
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // Sections Editor
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        Text("Edit Resume Sections", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                if (currentResume.userPhotoUri.isNotBlank()) {
                                    AsyncImage(
                                        model = currentResume.userPhotoUri,
                                        contentDescription = "Passport Photo",
                                        modifier = Modifier
                                            .size(width = 60.dp, height = 75.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .border(2.dp, PrimaryPurple, RoundedCornerShape(8.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(width = 60.dp, height = 75.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(PrimaryPurple.copy(alpha = 0.1f))
                                            .border(1.dp, PrimaryPurple.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.AddAPhoto, contentDescription = null, tint = PrimaryPurple)
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Passport Size Photo", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Update or attach photo to resume", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { photoPickerLauncher.launch("image/*") },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text(if (currentResume.userPhotoUri.isBlank()) "Upload Photo" else "Change", fontSize = 12.sp)
                                        }
                                        if (currentResume.userPhotoUri.isNotBlank()) {
                                            OutlinedButton(
                                                onClick = {
                                                    val updated = currentResume.copy(userPhotoUri = "")
                                                    currentResume = updated
                                                    viewModel.updateActiveResume(updated)
                                                },
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                            ) {
                                                Text("Remove", fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = currentResume.name,
                            onValueChange = { newVal ->
                                val updated = currentResume.copy(name = newVal)
                                currentResume = updated
                                viewModel.updateActiveResume(updated)
                            },
                            label = { Text("Full Name") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = currentResume.targetJobTitle,
                            onValueChange = { newVal ->
                                val updated = currentResume.copy(targetJobTitle = newVal)
                                currentResume = updated
                                viewModel.updateActiveResume(updated)
                            },
                            label = { Text("Target Job Title") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = currentResume.email,
                            onValueChange = { newVal ->
                                val updated = currentResume.copy(email = newVal)
                                currentResume = updated
                                viewModel.updateActiveResume(updated)
                            },
                            label = { Text("Email") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = currentResume.phone,
                            onValueChange = { newVal ->
                                val updated = currentResume.copy(phone = newVal)
                                currentResume = updated
                                viewModel.updateActiveResume(updated)
                            },
                            label = { Text("Phone") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = currentResume.summary,
                            onValueChange = { newVal ->
                                val updated = currentResume.copy(summary = newVal)
                                currentResume = updated
                                viewModel.updateActiveResume(updated)
                            },
                            label = { Text("Professional Summary") },
                            modifier = Modifier.fillMaxWidth().height(140.dp),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                3 -> {
                    // Style Customizer
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        Text("Customize Design & Formatting", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(16.dp))

                        Text("Primary Color Palette", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(themeColors) { hex ->
                                val color = Color(android.graphics.Color.parseColor(hex))
                                val isSelected = hex.equals(currentResume.themeColorHex, ignoreCase = true)
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .border(if (isSelected) 3.dp else 0.dp, PrimaryPurple, CircleShape)
                                        .clickable {
                                            val updated = currentResume.copy(themeColorHex = hex)
                                            currentResume = updated
                                            viewModel.updateActiveResume(updated)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text("Font Family", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Inter", "Serif", "Monospace").forEach { style ->
                                val isSelected = currentResume.fontStyle == style
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        val updated = currentResume.copy(fontStyle = style)
                                        currentResume = updated
                                        viewModel.updateActiveResume(updated)
                                    },
                                    label = { Text(style) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPurple, selectedLabelColor = Color.White)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text("Font Size: ${currentResume.fontSize.toInt()} sp", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Slider(
                            value = currentResume.fontSize,
                            onValueChange = { newVal ->
                                val updated = currentResume.copy(fontSize = newVal)
                                currentResume = updated
                                viewModel.updateActiveResume(updated)
                            },
                            valueRange = 10f..16f
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text("Margins Padding: ${currentResume.margins.toInt()} dp", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Slider(
                            value = currentResume.margins,
                            onValueChange = { newVal ->
                                val updated = currentResume.copy(margins = newVal)
                                currentResume = updated
                                viewModel.updateActiveResume(updated)
                            },
                            valueRange = 8f..28f
                        )
                    }
                }
            }
        }
    }
}
