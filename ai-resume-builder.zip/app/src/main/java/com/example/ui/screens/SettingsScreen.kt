package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.PrimaryPurple

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val isDarkMode by viewModel.isDarkMode.collectAsState()

    val storagePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        Toast.makeText(context, "Storage permissions updated", Toast.LENGTH_SHORT).show()
    }

    var defaultPaperSize by remember { mutableStateOf("A4") }
    var autoSaveEnabled by remember { mutableStateOf(true) }
    var aiSuggestionsEnabled by remember { mutableStateOf(true) }
    var notificationsEnabled by remember { mutableStateOf(true) }

    var showResetDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showFeedbackDialog by remember { mutableStateOf(false) }
    var feedbackText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("App Settings", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Appearance & Display
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, contentDescription = null, tint = PrimaryPurple)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Appearance & Theme", fontWeight = FontWeight.Bold, color = PrimaryPurple, fontSize = 15.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Dark Theme", fontWeight = FontWeight.Medium)
                            Text("Enable dark mode for app interface", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = { viewModel.toggleDarkMode(it) }
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Default Paper Size", fontWeight = FontWeight.Medium)
                            Text("Standard layout for exported PDF", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = defaultPaperSize == "A4",
                                onClick = { defaultPaperSize = "A4" },
                                label = { Text("A4") }
                            )
                            FilterChip(
                                selected = defaultPaperSize == "Letter",
                                onClick = { defaultPaperSize = "Letter" },
                                label = { Text("Letter") }
                            )
                        }
                    }
                }
            }

            // Section 2: AI & Assistant Features
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = PrimaryPurple)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AI & Editor Settings", fontWeight = FontWeight.Bold, color = PrimaryPurple, fontSize = 15.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Smart AI Writing Assistant", fontWeight = FontWeight.Medium)
                            Text("Show AI suggestions & summary generator", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = aiSuggestionsEnabled,
                            onCheckedChange = { aiSuggestionsEnabled = it }
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto-Save Drafts", fontWeight = FontWeight.Medium)
                            Text("Automatically save resume changes while editing", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = autoSaveEnabled,
                            onCheckedChange = { autoSaveEnabled = it }
                        )
                    }
                }
            }

            // Section 3: Notifications
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Notifications, contentDescription = null, tint = PrimaryPurple)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Notifications & Reminders", fontWeight = FontWeight.Bold, color = PrimaryPurple, fontSize = 15.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Career & Job Tips", fontWeight = FontWeight.Medium)
                            Text("Receive periodic resume enhancement tips", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = notificationsEnabled,
                            onCheckedChange = { notificationsEnabled = it }
                        )
                    }
                }
            }

            // Section 4: Data & Cache
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Storage, contentDescription = null, tint = PrimaryPurple)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Storage & Maintenance", fontWeight = FontWeight.Bold, color = PrimaryPurple, fontSize = 15.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val perms = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                                    arrayOf(
                                        android.Manifest.permission.READ_MEDIA_IMAGES,
                                        android.Manifest.permission.POST_NOTIFICATIONS
                                    )
                                } else {
                                    arrayOf(
                                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                                    )
                                }
                                storagePermissionLauncher.launch(perms)
                            }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Request Storage Permission", fontWeight = FontWeight.Medium)
                            Text("Grant permission to save PDF resumes and access photo gallery", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = PrimaryPurple)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                Toast.makeText(context, "Temporary cache cleared successfully", Toast.LENGTH_SHORT).show()
                            }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Clear Temporary Cache", fontWeight = FontWeight.Medium)
                            Text("Free up space without losing saved resumes", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.CleaningServices, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    OutlinedButton(
                        onClick = { showResetDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reset App Data")
                    }
                }
            }

            // Section 5: Support & About App
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = PrimaryPurple)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("About & Support", fontWeight = FontWeight.Bold, color = PrimaryPurple, fontSize = 15.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showFeedbackDialog = true }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Send Feedback & Suggestions", fontWeight = FontWeight.Medium)
                        Icon(Icons.Default.RateReview, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showPrivacyDialog = true }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Privacy Policy & Terms", fontWeight = FontWeight.Medium)
                        Icon(Icons.Default.PrivacyTip, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("App Version", fontWeight = FontWeight.Medium)
                        Text("v2.5.0 (Build 2026)", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (showFeedbackDialog) {
        AlertDialog(
            onDismissRequest = { showFeedbackDialog = false },
            title = { Text("Send Feedback") },
            text = {
                Column {
                    Text("We'd love to hear your thoughts to improve Resume Studio.")
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        placeholder = { Text("Write your feedback here...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showFeedbackDialog = false
                        Toast.makeText(context, "Thank you for your feedback!", Toast.LENGTH_SHORT).show()
                        feedbackText = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                ) {
                    Text("Submit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFeedbackDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = {
                Text(
                    "Privacy Policy",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Box(modifier = Modifier.heightIn(max = 420.dp)) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Privacy Policy for Resume Studio",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = PrimaryPurple
                        )
                        Text(
                            text = "Effective Date: July 26, 2026",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Welcome to Resume Studio. Your privacy is important to us. This Privacy Policy explains how Resume Studio collects, uses, stores, and protects your information when you use our application.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("1. Information We Collect", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Resume Studio may collect the following information:\n" +
                                    "• Full Name\n" +
                                    "• Email Address\n" +
                                    "• Profile Photo (optional)\n" +
                                    "• Resume Information (education, experience, skills, projects, certifications, etc.)\n" +
                                    "• Device Information (Android version, device model)\n" +
                                    "• App Usage Analytics\n" +
                                    "• Crash Reports\n" +
                                    "• IP Address (when required for security)\n" +
                                    "• Firebase Authentication information (if you sign in)",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("2. How We Use Your Information", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "We use your information to:\n" +
                                    "• Create and manage your resume.\n" +
                                    "• Save and sync your resumes across devices.\n" +
                                    "• Improve app performance and user experience.\n" +
                                    "• Provide AI-powered resume suggestions.\n" +
                                    "• Generate ATS-friendly resumes.\n" +
                                    "• Send password reset emails.\n" +
                                    "• Respond to support requests.\n" +
                                    "• Prevent fraud and misuse.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("3. AI Features", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Resume Studio uses AI to help generate and improve resume content. The information you provide may be processed by AI services to generate professional resume text and suggestions.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("4. Firebase Services", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Our app may use Firebase services, including:\n" +
                                    "• Firebase Authentication\n" +
                                    "• Cloud Firestore\n" +
                                    "• Firebase Storage\n" +
                                    "• Firebase Analytics\n" +
                                    "• Firebase Crashlytics\n" +
                                    "• Firebase Cloud Messaging (optional)\n" +
                                    "These services help us provide secure authentication, cloud storage, analytics, and app improvements.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("5. Data Storage", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Your resumes may be stored:\n" +
                                    "• On your device.\n" +
                                    "• In secure cloud storage if you sign in.\n" +
                                    "• In Firebase Cloud Firestore and Firebase Storage.\n" +
                                    "We take reasonable measures to protect your information.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("6. Advertising", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Resume Studio may display advertisements using Google AdMob.\n" +
                                    "AdMob may collect non-personal information such as:\n" +
                                    "• Device identifiers\n" +
                                    "• Advertising ID\n" +
                                    "• Approximate location\n" +
                                    "• App usage information\n" +
                                    "For more information, please review Google's Privacy Policy.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("7. Permissions", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "The app may request the following permissions:\n" +
                                    "• Internet – To access AI services and cloud features.\n" +
                                    "• Storage – To save and export PDF resumes.\n" +
                                    "• Camera – To upload or capture a profile photo (optional).\n" +
                                    "• Notifications – To send important updates (optional).\n" +
                                    "Permissions are requested only when required.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("8. Data Sharing", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "We do not sell your personal information.\n" +
                                    "We may share limited information only with trusted service providers such as:\n" +
                                    "• Google Firebase\n" +
                                    "• Google AdMob\n" +
                                    "• AI service providers used for resume generation\n" +
                                    "These providers process data only to deliver app functionality.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("9. Data Security", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "We use industry-standard security practices to help protect your information. However, no method of electronic storage or transmission is completely secure.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("10. Children's Privacy", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Resume Studio is not intended for children under the age of 13. We do not knowingly collect personal information from children.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("11. Your Rights", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "You may:\n" +
                                    "• Access your information.\n" +
                                    "• Update your profile.\n" +
                                    "• Delete your account.\n" +
                                    "• Delete your resumes.\n" +
                                    "• Request removal of your personal data.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("12. Changes to This Privacy Policy", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "We may update this Privacy Policy from time to time. Any changes will be posted within the app or on our website, and the updated Effective Date will be revised.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Text("13. Contact Us", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "If you have any questions or concerns regarding this Privacy Policy, please contact us:\n" +
                                    "App Name: Resume Studio\n" +
                                    "Email: gyanguru623@gmail.com\n\n" +
                                    "Thank you for using Resume Studio. Your privacy and data security are important to us.",
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showPrivacyDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                ) {
                    Text("Close")
                }
            }
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset App Data?") },
            text = { Text("This will reset all resumes to standard sample data. This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetToSeedData()
                        showResetDialog = false
                        Toast.makeText(context, "App data reset successfully", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Reset Data")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            }
        )
    }
}

