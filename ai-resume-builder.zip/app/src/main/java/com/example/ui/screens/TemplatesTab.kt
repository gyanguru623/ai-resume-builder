package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FrostedBadge
import com.example.ui.components.GlassCard
import com.example.ui.templates.ResumeTemplate
import com.example.ui.templates.ResumeTemplateCatalog
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.PrimaryPurple

@Composable
fun TemplatesTab(
    onSelectTemplate: (ResumeTemplate) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("All") }

    val filteredTemplates = remember(selectedCategory) {
        if (selectedCategory == "All") {
            ResumeTemplateCatalog.templates
        } else {
            ResumeTemplateCatalog.templates.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 16.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Text(
                text = "Resume Templates",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "50+ ATS-optimized templates trusted by recruiters",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Categories Filter Carousel
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ResumeTemplateCatalog.categories) { category ->
                val isSelected = category == selectedCategory
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategory = category },
                    label = { Text(category, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryPurple,
                        selectedLabelColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Templates Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(filteredTemplates) { template ->
                TemplateCardItem(
                    template = template,
                    onUse = { onSelectTemplate(template) }
                )
            }
        }
    }
}

@Composable
fun TemplateCardItem(
    template: ResumeTemplate,
    onUse: () -> Unit
) {
    val primaryColor = try {
        Color(android.graphics.Color.parseColor(template.primaryColorHex))
    } catch (e: Exception) {
        PrimaryPurple
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        elevation = 2.dp,
        onClick = onUse
    ) {
        Column {
            // Visual Miniature Preview Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(primaryColor.copy(alpha = 0.12f))
                    .padding(10.dp)
            ) {
                // Dummy mini document mockup
                Card(
                    modifier = Modifier.fillMaxSize(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (template.hasPhoto) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .background(primaryColor, RoundedCornerShape(4.dp))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .width(50.dp)
                                        .height(6.dp)
                                        .background(primaryColor, RoundedCornerShape(2.dp))
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Box(
                                    modifier = Modifier
                                        .width(30.dp)
                                        .height(4.dp)
                                        .background(Color.LightGray, RoundedCornerShape(2.dp))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(primaryColor.copy(alpha = 0.3f)))
                        Spacer(modifier = Modifier.height(6.dp))

                        repeat(4) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(if (it % 2 == 0) 0.9f else 0.7f)
                                    .height(3.dp)
                                    .background(Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(1.dp))
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }

                // Badge top right
                if (template.isPremium) {
                    Surface(
                        modifier = Modifier.align(Alignment.TopEnd),
                        color = Color(0xFFFFB300),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            Icons.Default.WorkspacePremium,
                            contentDescription = "PRO",
                            tint = Color.White,
                            modifier = Modifier.padding(4.dp).size(14.dp)
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = template.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    FrostedBadge(
                        text = template.previewBadge,
                        badgeColor = AccentGreen
                    )

                    if (template.hasPhoto) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Photo,
                            contentDescription = "Photo",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onUse,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(34.dp),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("Use Template", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
