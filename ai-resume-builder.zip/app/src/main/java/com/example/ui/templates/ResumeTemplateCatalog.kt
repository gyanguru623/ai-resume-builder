package com.example.ui.templates

data class ResumeTemplate(
    val id: String,
    val name: String,
    val category: String, // Professional, Modern, Creative, Minimal, Corporate, Student, Developer, Designer, Executive, Simple
    val description: String,
    val primaryColorHex: String,
    val hasPhoto: Boolean = false,
    val isPremium: Boolean = false,
    val fontStyleName: String = "Inter",
    val layoutType: String = "single_column", // single_column, split_left, header_accent, ats_clean, code_mono, executive_line
    val previewBadge: String = "ATS Friendly"
)

object ResumeTemplateCatalog {

    val categories = listOf(
        "All",
        "Professional",
        "Modern",
        "Creative",
        "Minimal",
        "Corporate",
        "Student",
        "Developer",
        "Designer",
        "Executive",
        "Simple"
    )

    val templates: List<ResumeTemplate> = listOf(
        ResumeTemplate("modern_purple", "Modern Purple", "Modern", "Clean 2-column layout with vibrant primary header and photo avatar.", "#6C63FF", true, false, "Inter", "split_left", "100% ATS Ready"),
        ResumeTemplate("ats_pro_slate", "ATS Professional Slate", "Professional", "High-parsing ATS single-column template optimized for executive resume screeners.", "#1E293B", false, false, "Inter", "ats_clean", "Recruiter #1 Choice"),
        ResumeTemplate("student_fresh", "Student Entry-Level", "Student", "Emphasizes education, projects, skills, and certifications for freshers.", "#059669", true, false, "Inter", "header_accent", "Fresher Choice"),
        ResumeTemplate("corporate_blue", "Corporate Sapphire", "Corporate", "Standard double-bordered corporate layout widely trusted in finance and law.", "#2563EB", false, false, "Lato", "single_column", "Corporate Standard"),
        ResumeTemplate("minimal_light", "Minimal Pure White", "Minimal", "Ultra-clean minimalist document with subtle divider lines.", "#475569", false, false, "Inter", "single_column", "Minimalist"),
        ResumeTemplate("creative_teal", "Creative Emerald Accent", "Creative", "Bold header banner with rounded skill badges and progress bars.", "#00C896", true, true, "Montserrat", "header_accent", "Visual Impact"),
        ResumeTemplate("simple_classic", "Simple Classic Times", "Simple", "Traditional timeless single-page resume layout.", "#334155", false, false, "Playfair Display", "ats_clean", "Classic"),

        // Additional templates
        ResumeTemplate("modern_emerald", "Modern Emerald", "Modern", "Stylish green gradient banner with rounded section cards.", "#059669", true, false, "Inter", "split_left"),
        ResumeTemplate("modern_crimson", "Modern Crimson", "Modern", "Bold red header accents with structured grid items.", "#DC2626", true, true, "Poppins", "header_accent"),
        ResumeTemplate("modern_indigo", "Modern Indigo", "Modern", "Deep purple-blue layout with sidebar skills matrix.", "#4F46E5", true, false, "Inter", "split_left"),
        ResumeTemplate("modern_sunset", "Modern Sunset Coral", "Modern", "Warm coral accent tones with crisp typography.", "#EA580C", true, true, "Montserrat", "header_accent"),

        ResumeTemplate("pro_sapphire", "Sapphire Corporate", "Professional", "Crisp blue lines with bold section headings.", "#1D4ED8", false, false, "Roboto", "single_column"),
        ResumeTemplate("pro_slate_gold", "Slate & Champagne", "Professional", "Gold bullet points on clean slate background.", "#334155", true, true, "Lato", "executive_line"),
        ResumeTemplate("pro_classic_grid", "Classic Business Grid", "Professional", "Structured multi-row experience table.", "#1E293B", false, false, "Roboto", "ats_clean"),

        ResumeTemplate("creative_violet", "Creative Electric Violet", "Creative", "Modern electric violet canvas with photo badge.", "#7C3AED", true, false, "Poppins", "split_left"),
        ResumeTemplate("creative_rose", "Creative Rose Gold", "Creative", "Elegant rose background highlight with rounded cards.", "#E11D48", true, true, "Playfair Display", "header_accent"),
        ResumeTemplate("creative_amber", "Creative Amber Gold", "Creative", "Bright energetic header banner with visual icons.", "#D97706", true, false, "Montserrat", "header_accent"),

        ResumeTemplate("minimal_dark_mode", "Minimal Midnight", "Minimal", "High contrast dark canvas with white crisp text.", "#0F172A", false, false, "Source Code Pro", "code_mono"),
        ResumeTemplate("minimal_mono_grey", "Minimal Charcoal", "Minimal", "Clean grey tones with generous padding.", "#4B5563", false, false, "Inter", "single_column"),
        ResumeTemplate("minimal_compact", "Minimal Compact 1-Page", "Minimal", "Tight compact layout fitting maximum experience on 1 page.", "#374151", false, false, "Roboto", "ats_clean"),

        ResumeTemplate("corp_global", "Global Enterprise", "Corporate", "Corporate standard trusted by Fortune 500 recruiters.", "#1E40AF", false, false, "Lato", "single_column"),
        ResumeTemplate("corp_banking", "Investment Banking", "Corporate", "Conservative, highly structured traditional layout.", "#1E293B", false, false, "Merriweather", "single_column"),
        ResumeTemplate("corp_consulting", "Management Consultant", "Corporate", "Results-oriented layout placing key achievements top-center.", "#0F766E", true, true, "Roboto", "executive_line"),

        ResumeTemplate("student_campus", "Campus Graduate", "Student", "Places projects and campus achievements front and center.", "#2563EB", true, false, "Inter", "split_left"),
        ResumeTemplate("student_intern", "Internship Ready", "Student", "Clean skills-first fresher resume.", "#059669", false, false, "Poppins", "single_column"),
        ResumeTemplate("student_academic", "Academic Honors", "Student", "Highlights research, GPA, and academic awards.", "#4338CA", true, false, "Merriweather", "ats_clean"),

        ResumeTemplate("dev_fullstack", "Full Stack Stack Overflow", "Developer", "Special sections for GitHub repos, Tech Stack, and Open Source.", "#0284C7", false, false, "Source Code Pro", "code_mono"),
        ResumeTemplate("dev_cyber", "Cybersecurity Specialist", "Developer", "Clean monospaced technical summary layout.", "#15803D", false, false, "Source Code Pro", "code_mono"),
        ResumeTemplate("dev_ai_ml", "AI & Data Scientist", "Developer", "Includes dedicated research paper & model portfolio links.", "#6D28D9", true, true, "Inter", "code_mono"),

        ResumeTemplate("designer_ux", "UX Architect Clean", "Designer", "Features project case study links and design toolkit tags.", "#C026D3", true, false, "Poppins", "split_left"),
        ResumeTemplate("designer_brand", "Brand Specialist", "Designer", "Sleek typography pairing with custom primary accent tint.", "#0284C7", true, true, "Montserrat", "header_accent"),

        ResumeTemplate("exec_ceo", "Chief Executive Gold", "Executive", "Subtle metallic gold headers and executive summary emphasis.", "#92400E", true, true, "Playfair Display", "executive_line"),
        ResumeTemplate("exec_vp", "VP Engineering", "Executive", "Combines high-level strategy overview with metric metrics.", "#1E3A8A", true, true, "Merriweather", "executive_line"),

        ResumeTemplate("simple_outline", "Simple Bordered Outline", "Simple", "Thin outer border framing standard sections.", "#374151", false, false, "Roboto", "single_column"),
        ResumeTemplate("simple_clean_text", "Simple Pure Text", "Simple", "No photos or heavy graphics—pure clean text.", "#111827", false, false, "Inter", "ats_clean")
    )

    fun getTemplateById(id: String): ResumeTemplate {
        return templates.find { it.id == id } ?: templates.first()
    }
}
