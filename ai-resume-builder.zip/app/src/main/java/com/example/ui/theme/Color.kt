package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryPurple = Color(0xFF6C63FF)
val SecondaryPurple = Color(0xFF8E7CFF)
val LightPurple = Color(0xFFF0EEFF)
val AccentGreen = Color(0xFF00C896)
val AccentOrange = Color(0xFFFF8A65)
val AccentBlue = Color(0xFF29B6F6)

val SurfaceLight = Color(0xF7FFFFFF)
val SurfaceLightGlass = Color(0xEFFFFFFF)
val BackgroundLight = Color(0xFFF8F9FF)
val OnBackgroundLight = Color(0xFF0F172A)

val SurfaceDark = Color(0xEE1E293B)
val SurfaceDarkGlass = Color(0xCC0F172A)
val BackgroundDark = Color(0xFF0F172A)
val OnBackgroundDark = Color(0xFFF8FAFC)

val GlassBorderLight = Color(0x336C63FF)
val GlassBorderDark = Color(0x338E7CFF)
val FrostedBorderLight = Color(0xFFE2E8F0)
val FrostedBorderDark = Color(0x33334155)
